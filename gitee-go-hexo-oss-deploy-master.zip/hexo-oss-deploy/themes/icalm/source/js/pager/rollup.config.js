export default {
  entry: 'src/singlepager.js',
  format: 'umd',
  dest: 'dist/singlepager.js',
  moduleName: 'Pager'
};